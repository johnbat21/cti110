# This program takes the price of five items and will calculate the total price to be paid at checkout
# 3/1/21
# CTI-110 P2HW1 - Total Purchases
# John Batdorff
#
# The program gets the price of five items as input
# The program will then calculate the subtotal, sales tax total, and final total of those same five items
# The program lastly displays the subtotal, sales tax total, and final total back to the user
#
#
item_one = float(input('Enter the price of item #1: '))
item_two = float(input('Enter the price of item #2: '))
item_three = float(input('Enter the price of item #3: '))
item_four = float(input('Enter the price of item #4: '))
item_five = float(input('Enter the price of item #5: '))
subtotal = item_one + item_two + item_three + item_four + item_five
sales_tax = subtotal * 0.07
total = subtotal + sales_tax
print('')
print('-------Results-------')
print(f'Subtotal: {subtotal:.2f}')
print(f'Sales Tax: {sales_tax:.2f}')
print(f'Total: {total:.2f}')

