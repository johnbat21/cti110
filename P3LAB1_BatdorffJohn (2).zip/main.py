red = int(input())
green = int(input())
blue = int(input())

lowest = red

if green < lowest:
    lowest = green
if blue < lowest:
    lowest = blue

red = red - lowest
green = green - lowest
blue = blue - lowest

print(red,green,blue)