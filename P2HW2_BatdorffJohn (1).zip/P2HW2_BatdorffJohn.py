# CTI-110
# P2HW2 - Score Avg
# John Batdorff
# 3/3/22
#
# This code will ask for seven scores from the user as input
# The code will then be able to determine the lowest score of the seven, remove it, and calculate the average score from the remaining six scores
# Lastly, the code will display the lowest score followed by a list of the remaining scores in a list followed by the average of the list
#
score_one = float(input('Enter score #1: '))
score_two = float(input('Enter score #2: '))
score_three = float(input('Enter score #3: '))
score_four = float(input('Enter score #4: '))
score_five = float(input('Enter score #5: '))
score_six = float(input('Enter score #6: '))
score_seven = float(input('Enter score #7: '))
                    
scores = [score_one, score_two, score_three, score_four, score_five, score_six, score_seven]
lowest = min(scores)
scores.remove(lowest)
average = sum(scores) / 6

print('')
print('')
print('-------------Results-------------')
print('Lowest Score  :', lowest)
print('Modified List :', scores)
print('Scores Average:', average)
print('---------------------------------')
