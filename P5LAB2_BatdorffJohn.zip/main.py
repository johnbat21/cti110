# Define your function here
def feet_to_steps(user_feet):
    feet = int (user_feet / 2.5)
    return feet

if __name__ == '__main__':
    user_feet = float(input())
    print(feet_to_steps(user_feet))