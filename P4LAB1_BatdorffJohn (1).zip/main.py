user_text = input()

characters = 0 
length = 0 
for i in user_text:
    if user_text[length] != ' ' and user_text[length] != '.' and user_text[length] != ',' and user_text[length] != '!':
        characters += 1
    length += 1
print(characters)
